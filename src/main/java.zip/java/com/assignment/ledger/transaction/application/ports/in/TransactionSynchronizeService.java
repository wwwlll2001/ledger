package com.assignment.ledger.transaction.application.ports.in;

import com.assignment.ledger.transaction.application.dto.TransactionDto;


public interface TransactionSynchronizeService {

    /**
     * Synchronize transaction data to elasticsearch.
     *
     * @param transactionDto transaction data
     */
    void synchronizeTransaction(TransactionDto transactionDto);
}
