package com.assignment.ledger.common.exception;

public class WalletTypeNotConsistentException extends RuntimeException {
    public WalletTypeNotConsistentException(String message) {
        super(message);
    }
}
