package com.assignment.ledger.wallet.domain;

public enum AssetType {
    FLAT_CURRENCY, CRYPTO, STOCK, BOND
}
