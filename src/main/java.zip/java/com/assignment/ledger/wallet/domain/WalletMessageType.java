package com.assignment.ledger.wallet.domain;

public enum WalletMessageType {
    BALANCE_CHANGE
}
