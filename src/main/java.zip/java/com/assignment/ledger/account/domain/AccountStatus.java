package com.assignment.ledger.account.domain;

public enum AccountStatus {
    OPEN, CLOSE
}
